(function() {
  jQuery(function() {
    return $('plantationListed').dataTable();
  });

}).call(this);
